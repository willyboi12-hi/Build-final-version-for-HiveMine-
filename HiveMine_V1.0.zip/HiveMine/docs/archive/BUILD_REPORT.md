# HiveMine Mobile V1 build and test report

## Source and JVM verification (2026-11-09)

- Engine suite: `bash tests/run.sh` — **476 passed, 0 failed**.
- Local crash-report store: **8 passed, 0 failed**.
- AI bridge and Safe Mode suite: **53 passed, 0 failed**.
- Floating AI tab suite: **23 passed, 0 failed**.
- Android wiring suite: **30 passed, 0 failed**.
- Runtime diagnostics suite: **12 passed, 0 failed**.
- Stale telemetry / pause / disconnect safety suite: **11 passed, 0 failed**.
- Phase 101-250 subsystem checks: **451 passed, 0 failed**.
- The crash-report store and Application bootstrap compile against the test fakes. Android framework and lifecycle behavior is not exercised by these JVM fakes.

## Android build status

- Gradle wrapper: pinned to 8.9.
- Android SDK environment variables are not configured in this execution environment.
- Gradle 8.9 distribution is not cached; this environment previously could not resolve `services.gradle.org` (`UnknownHostException`).
- Android lint: NOT RUN.
- Debug APK: NOT BUILT.
- Release APK: NOT BUILT.
- Physical-device validation: NOT RUN.
- Release signing: NOT CONFIGURED.

This report does not claim an APK build or device test. Run the Android Gradle tasks in a provisioned Android SDK environment and complete `DEVICE_TEST_MATRIX.md` before release.


## Yellow+4 verification update (2026-11-09)

- Engine suite: `bash tests/run.sh` — **476 passed, 0 failed**.
- AI/app suite: all tests passed, including the expanded Yellow vision loop (**13 passed**) and the new player tracker checks (**13 passed**).
- `AiControlHub` now retains one calibrated analyzer across frames; the app/bridge JVM suite compiles and exercises the changed path using test fakes.
- Restored the missing Unix and Windows Gradle wrapper launch scripts; the wrapper remains pinned to Gradle 8.9.
- Android Gradle build was not run: this environment has no cached Gradle 8.9 distribution, Android SDK, or installed Gradle executable. No APK or device validation is claimed.
