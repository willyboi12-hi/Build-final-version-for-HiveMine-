# Archived status documents

These pass, readiness and report documents were written at different points and disagree with each other. They are kept for history only. Current status lives in `hivemine-ai/PHASE_LEDGER.md`, and release gates in `PRODUCTION_READINESS.md`.
- `hivemine-ai_documentation_PHASE_LEDGER.md`: older copy of the ledger, superseded by `hivemine-ai/PHASE_LEDGER.md`.
