# HiveMine AI Handoff

## What this project is

HiveMine AI is included in the combined HiveMine Mobile v1.8.0 Android project as the `:ai-core` Java module. HiveMine Mobile remains the execution engine; the AI layer plans and manages authorized requests.

## Versions

- HiveMine Mobile: 1.8.0
- HiveMine AI core: 2.00

## How to test

```bash
bash tests/run.sh
bash tests/run-ai.sh
```

These are JVM and app-wiring tests. Android Gradle compilation, APK installation, and device tests are still required.

## Current boundaries

- AI START/RECOVER require the user-enabled AI control setting.
- STOP remains an emergency command and is confirmed through a later macro status observation.
- The Android status poll feeds command completion and live telemetry into the AI manager.
- SQLite stores bounded operational events; this is not yet persistent learned-policy memory.
- The specialist fleet is not yet fully connected to an autonomous task-graph execution loop.

## Do not

- Bypass `AutomationController` authorization.
- Treat JVM wiring checks as device validation.
- Claim complete autonomous specialist orchestration, learned-policy training, or production readiness without additional implementation and evidence.
- Claim undetectable automation or account safety.
