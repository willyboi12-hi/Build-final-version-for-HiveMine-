# HiveMine Mobile V1 — Red Feature Pass

## Focus
Route integrity and bounded route recovery.

## Implemented
- Added `RouteVerificationGuard` for active field routes.
- Requires two consecutive high-confidence field mismatches before requesting realignment.
- Uses measured player velocity to refresh a route movement watchdog.
- Holds on stale/unknown observations rather than treating them as route failure.
- Requests bounded realignment after sustained no-motion.
- Stops safely when a route has run too long without any known player position.
- Added JVM regression coverage for field mismatch, movement, stale observations, stall recovery and safe-stop behavior.

## Boundary
This pass does not claim general field recognition or autonomous path planning. It verifies the route against the world-state signals already produced by HiveMine.

## Verification
Run `bash tests/run-ai.sh` and `bash tests/run.sh`. Physical Android/device validation remains a separate release gate.

## Version
- Android `versionCode`: 21
- Android `versionName`: 1.0.3
- Baseline: HiveMine V1.0
