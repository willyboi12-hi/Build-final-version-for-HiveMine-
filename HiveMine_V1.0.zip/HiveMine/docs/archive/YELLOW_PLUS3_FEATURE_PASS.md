# HiveMine Mobile V1 — Yellow+3 Feature Pass

## Implemented
- Added dependency-free calibrated screenshot numeric OCR (`TemplateDigitOcr`) for numeric on-screen counters. It uses user-calibrated glyph templates and confidence thresholds rather than pretending arbitrary text recognition.
- Added `NumericTelemetryReader` bridge for cumulative pollen counters. Bag percentage remains separate from cumulative pollen and is never treated as output telemetry.
- Added `QuestOcrPipeline` to sanitize, normalize, deduplicate, and reject malformed/low-quality OCR rows before Quest Manager ingestion.
- Connected the OCR sanitation layer to `AiControlHub.observeQuestOcrLines`.
- Added focused regression coverage for numeric screenshot OCR behavior and quest OCR sanitation.
- Extended the AI test runner to execute the new checks.

## Verification
- Main JVM suite: 476 passed, 0 failed.
- Existing AI/Android suites: all passed.
- New Quest OCR pipeline: 2 passed, 0 failed.
- New numeric screenshot OCR: 3 passed, 0 failed.

## Accuracy boundary
The numeric OCR is deliberately calibration-driven and currently recognizes digits, not arbitrary quest prose. A full general-purpose screenshot OCR engine would require an OCR model/provider bundled or installed on Android and device-level validation. The new interfaces are designed so such a provider can feed the same Quest Manager without changing its safety rules.

## Release boundary
No APK/device validation or release signing is claimed by this report. The source remains the clean-room project tree and standard Gradle build tooling only.
