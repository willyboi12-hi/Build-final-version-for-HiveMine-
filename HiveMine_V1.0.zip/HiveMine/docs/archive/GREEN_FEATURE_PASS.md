# HiveMine Mobile V1 — Green Feature Pass

## Focus
Quest completion evidence and safe turn-in gating.

## Implemented
- Added `QuestCompletionEvidenceGate` to fuse visual green Complete/Turn In evidence with the Quest Manager's `READY_TO_TURN_IN` objective state.
- Requires two fresh confirmations inside a 5-second evidence window before a quest turn-in is authorized.
- A visual green button by itself can no longer authorize a blind turn-in.
- Missing, stale, active, or conflicting quest state clears the turn-in evidence.
- Integrated the gate into the AccessibilityService smart-quest flow.
- Added JVM regression coverage for single-frame false positives, active quests, expired evidence, missing objectives, and repeated confirmed completion.

## Boundary
This pass does not claim general-purpose screenshot OCR. Existing accessibility text and any permitted OCR provider still feed the Quest Manager. Physical Android/device validation remains a separate release gate.

## Verification
Run `bash tests/run-ai.sh` and `bash tests/run.sh`.

## Version
- Android `versionCode`: 22
- Android `versionName`: 1.0.4
- Baseline: HiveMine V1.0
