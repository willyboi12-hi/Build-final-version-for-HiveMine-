# HiveMine Blue Feature Pass

## Closed-loop farming action optimization

Blue adds a bounded farming-action pacing layer on top of Yellow/Orange/Red/Green:

- Uses the verified player velocity already produced by the vision tracker.
- When the player is still moving quickly after a route transition, farming is held briefly instead of immediately competing with route motion.
- The settle window is bounded at 1.5 seconds, so noisy velocity cannot stall the macro indefinitely.
- Full-bag routing remains authoritative: field + verified full bag returns to hive; hive + verified full bag converts.
- Unknown/stale world state never becomes an invented farming command.
- The optimizer is pure decision logic and does not directly actuate Android gestures.
- Added JVM regression coverage for fast-motion settling, normal farming, full-bag routing, and AutonomyLoop integration.

## Validation

`tests/run-ai.sh` includes the new `FarmingActionOptimizerChecks` suite. Physical Android/device validation is not performed by this environment.
