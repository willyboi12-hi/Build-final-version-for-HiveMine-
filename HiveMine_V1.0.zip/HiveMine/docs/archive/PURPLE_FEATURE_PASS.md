# Purple Feature Pass

Implemented the Purple adaptive-learning pass on top of Blue Plus8.

- Added uncertainty-aware `AdaptiveStrategySelector`.
- Uses only verified strategy runs already recorded by `StrategyPerformanceLedger`.
- Scores candidates using observed pollen/hour minus a standard-error penalty.
- Requires minimum evidence and an 8% evidence-adjusted margin before recommending a switch.
- Exposes the recommendation through `ManagerRuntimeService` without changing the user's active strategy automatically.
- Added regression coverage for strong evidence, high-variance evidence, and rejection of unverified runs.

This pass is recommendation-only; it does not silently alter user-selected farming patterns.
