# HiveMine Mobile V1 — Yellow+4 Feature Pass

## Scope
This pass focuses on one Yellow workstream: improve the reliability of calibrated player localization. It does not claim to complete general-purpose vision, autonomous path correction, quest text OCR, or device validation.

## Implemented
- Added `PlayerPositionTracker`, an ROI-bounded 8-connected-component tracker using the calibrated player color.
- Rejects components smaller than four pixels and implausibly large connected background patches.
- Scores detections using component quality and distance from the previous accepted position, with a bounded movement gate.
- Smooths accepted position estimates and measures normalized screen velocity (screen widths/heights per second).
- Keeps the previous track internally for short-term reacquisition, but emits an unknown observation when the player is not detected; it does not publish a stale predicted coordinate as a live detection.
- Added velocity-known/X/Y fields to immutable `WorldState`; existing constructors remain source-compatible.
- Preserves measured velocity through `TemporalWorldStateFilter` and stale-state copies in `WorldStateFusion`.
- Changed `AiControlHub` to reuse the calibrated `VisionWorldAnalyzer` across consecutive screenshot frames. Saving a new calibration clears the analyzer and track.
- Added regression coverage for initial detection, centroid accuracy, movement direction/velocity, a larger distant same-color distraction, single-pixel noise, temporary loss, reacquisition, distant-blob rejection, world-state propagation, temporal fusion and stale-state metadata.

## Verification
- `bash tests/run.sh`: **476 passed, 0 failed**.
- `bash tests/run-ai.sh`: all suites passed; includes the new **13-check PlayerPositionTrackerChecks** and expanded Yellow vision loop checks.
- The Yellow vision analyzer is compiled by the JVM suite and is exercised with synthetic frames.

## Boundaries / next Yellow work
- Player recognition remains a calibrated color-component heuristic; it can fail when the avatar/effects blend into the sampled color or the selected region excludes the avatar.
- The analyzer now produces velocity, but the farming movement executor has not yet been changed to use player position for closed-loop steering.
- Point-picking calibration is still a backend wizard; the complete Android touch-overlay workflow remains future work.
- Field/hive recognition, continuous general OCR, real cumulative pollen source, and adaptive pattern outcomes still need production integration.
- Android Gradle build, lint, APK signing, Roblox gameplay capture, and physical-device validation were not available in this environment and are not claimed.

## Version
- Android `versionCode`: 19
- Android `versionName`: 1.0.1
- Package baseline: `HiveMine_Mobile_V1_Yellow_Plus3`
