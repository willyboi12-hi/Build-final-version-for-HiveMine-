# HiveMine Mobile V1 — Orange Feature Pass

## Focus
Perception integrity for the closed-loop vision publisher.

## Implemented
- Added `ObservationQualityGate` to reject non-monotonic capture timestamps.
- Added duplicate-frame detection using the existing whole-frame content hash.
- Added a 2.5 second frozen-screen threshold; repeated screenshots beyond that window are rejected rather than published as fresh world state.
- Reset the gate with vision calibration/test lifecycle resets.
- Added Android integration in `AiControlHub.observeVisionFrame()` before world-state publication.
- Frozen-screen events are persisted as diagnostics without retaining screenshot pixels.
- Added regression coverage for first-frame acceptance, duplicate rejection, timestamp rollback, fresh-frame recovery, frozen-screen rejection, and reset behavior.

## Safety behavior
The gate does not fabricate player, bag, field, or scene values. A rejected observation simply leaves the existing TTL/fusion policy in control. This prevents a frozen Roblox screen from being mistaken for continued successful automation.

## Verification
Run `bash tests/run-ai.sh` and the normal JVM suite. Physical Android/device validation remains a separate release gate.

## Boundary
This pass does not claim general field/hive recognition or perfect Roblox scene classification; it hardens the observation boundary those detectors rely on.
