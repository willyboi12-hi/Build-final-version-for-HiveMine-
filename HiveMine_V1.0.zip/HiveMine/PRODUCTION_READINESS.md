# Production readiness

This is an evidence-based report. Passing JVM tests and wiring fakes is not proof of an Android APK build or physical-device readiness.

| Gate | Status | Evidence / next action |
|---|---|---|
| Supplied/fixed ZIP integrity | PASS | Archive integrity is checked when packaging |
| Engine JVM suite | PASS | `bash tests/run.sh`: 476 passed, 0 failed |
| AI/app wiring suite | PASS | `bash tests/run-ai.sh`: crash store 8, bridge/Safe Mode 53, tab 23, Android wiring 30, diagnostics 12, telemetry safety 11; phase subsystem checks 451; all passed |
| Runtime command monitor | SOURCE + JVM-WIRING VERIFIED | Dedicated Android service ticker feeds live MacroPort status to bridge and AI state; fakes verify transitions; device runtime remains unverified |
| Screenshot-derived telemetry | SOURCE + JVM-WIRING VERIFIED | Existing `AutoSense`/`BagReader` screenshot loop feeds bag/scene telemetry; one-second watchdog detects missing first frames and stale frames on supported Android versions |
| Calibrated player localization | SOURCE + JVM-TEST VERIFIED | Connected-component tracker rejects isolated specks, follows the nearest plausible component, smooths location/velocity, and reports misses as unknown; live capture and calibration accuracy still require device/game validation |
| Android SQLite operational history | SOURCE + JVM-WIRING VERIFIED | `HiveMineAiMemoryDb` stores bounded event summaries and restores recent history in the harness |
| Process crash marker | SOURCE + JVM-STORE VERIFIED | `HiveMineApplication` installs a delegating uncaught-exception handler; only timestamp, thread and exception type are persisted; device lifecycle remains unverified |
| Overlay live status | SOURCE + JVM-WIRING VERIFIED | Selected field, macro state/duration, manager goal summary and persisted events replace static sample labels; actual rendering requires device validation |
| Gradle project configuration | CONFIGURED | Android Gradle Plugin 8.7.3 / Gradle wrapper 8.9; run in a network-enabled Android SDK environment |
| Android lint | NOT RUN | Run `./gradlew :app:lintDebug` |
| Debug APK | NOT RUN | Run `./gradlew :app:assembleDebug` |
| Release APK | NOT RUN | Run `./gradlew :app:assembleRelease` |
| Physical-device validation | NOT RUN | Complete `DEVICE_TEST_MATRIX.md`, including accessibility, screenshot failure, STOP and recovery paths |
| Release signing | NOT CONFIGURED | Configure owner-managed signing secrets outside the repository |

## Remaining product-level work

1. Specialist capability routing is present in the Manager runtime and specialist registry, but the Android path still uses bounded telemetry rather than exposing every specialist as an independent live task worker.
2. The generic `VisionAI` analyzer and `LearningAI` remain bounded by structured live inputs. Calibrated player-color tracking now estimates normalized position and velocity across consecutive screenshots, but field navigation and Random/Grid/Perimeter route execution remain procedural and time-based; movement has not yet been closed-loop corrected from this position estimate. This is not a claim of a learned vision policy.
3. Broader real-device validation is still required for service lifecycle, timing, screenshots, gesture completion, background restrictions, microphone/overlay behavior, and recovery.
4. CI now contains lint + debug/release assembly + JVM checks, but this environment cannot execute the Android build because Gradle 8.9 cannot be downloaded. Release signing still requires owner-managed keystore secrets.
5. Quest OCR/progress extraction and verified quest completion are not implemented; current quest actions use saved taps and user-supplied goals.
6. Reconnect screen verification and one telemetry-gated conversion retry are implemented in source, but need device tests across game loading, screenshot failure and scene misclassification. Reconnect launch and screenshot-request exceptions now stop safely with an explicit report.
7. The new crash marker intentionally stores only timestamp, thread and exception class; Android's previous default crash handler still receives the original exception. Verify this startup integration on-device.
8. A real HTTPS update manifest/release endpoint must be supplied before automatic update delivery can be considered production-complete.

Do not label this project production-ready until every required gate has evidence. AI start/recovery remain gated by the user-controlled AI-control switch; STOP remains the emergency path. If the Safe Mode preference cannot be saved, HiveMine best-effort revokes the stored AI grant rather than reporting that the safety latch succeeded.
