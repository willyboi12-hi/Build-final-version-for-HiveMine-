# HIVEMINE AI UI Guide

## Java UI logic
- `UiController` — navigation + actions
- `ScreenContent` — all 12 sidebar screens
- `AiManagerService` — natural language plan/apply
- `BssIntentParser` / `BssPlanBuilder` — BSS-aware, supported settings only

## Web preview
Open `webui/index.html` in a browser for the dark charcoal / blue-purple / gold dashboard.

## Real controls only
Mapped to HiveMine Config keys: field, pattern, size, walkFirst, returnToField, questSmart, humanMode, fullAction, fullPercent, moveSpeed, aiControlEnabled.

Start/stop go through MacroPort + AutomationController.

## Not faked
Live honey/pollen charts, shop buys, and full loot pathing are documented as unavailable without device data / macro support.
