# Integration Guide — HiveMine AI in HiveMine 1.8.0

The combined project contains `:app` and `:ai-core`. This is not a separate adapter drop for HiveMine 1.7.0.

## Runtime path

```text
AI Manager / overlay
  -> AndroidMacroCommunicationBridge
  -> AutomationController
  -> AiMacroPort
  -> MacroAccessibilityService
  -> periodic MacroStatus observation
  -> command completion + ScreenState refresh
```

MacroAccessibilityService is the execution engine. The most recent macro observation is authoritative; cached AI state is only a projection of that observation.

## Authorization

- START and RECOVER require AI control to be enabled by the user and a connected macro. RECOVER also requires that the macro is currently running.
- STOP remains available as an emergency path, regardless of AI control setting.
- A STOP request is confirmed only after a later status observation reports `running == false`.
- All AI actions must use `AndroidMacroCommunicationBridge` / `AutomationController`; do not bypass the authorization boundary.

## Persistence

Supported settings are validated, committed, and read back before success is reported. `HiveMineAiMemoryDb` stores bounded operational summaries in SQLite. It does not yet implement a trained learned-policy store or replace all core memory abstractions.

## Verification

Run `bash tests/run.sh` and `bash tests/run-ai.sh`, then run Android lint and assemble tasks using a provisioned Gradle 8.9 + Android SDK 35 environment. Complete the physical-device test matrix before release. JVM wiring tests do not prove device correctness.
