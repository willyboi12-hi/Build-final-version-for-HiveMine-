# Phase 009 — Permission and Policy Supervision

## Scope

Phase 009 controls which capabilities may be used. The default is deny: a capability works only after the user grants it.

## Added classes

- `policy/PolicySupervisor` — grants, revocations, the hard-deny list, an audit trail, and `refuse`, which implements `AssignmentGate`.

## Rules

- Ungranted capabilities are refused.
- Capabilities under these prefixes are hard-denied and can never be granted: `input.`, `game.`, `android.`, `policy.`, `bypass.`.
- Hard-denied and invalid names are refused at grant time, and the refusal is recorded.
- Revoking a grant takes effect at the next assignment.
- The audit trail keeps the most recent 100 entries: grants, revocations, and refusals.

## Validation

Covered by `PolicyTests`: default-deny, grants and revocations, every hard-denied prefix, invalid names, integration with `TaskManager`, and the audit trail.

## Safety boundary

This supervisor is the gate between a task and its specialist. Nothing in this foundation can grant Android permissions or perform game actions. Hard-denied capabilities stay denied at runtime.
