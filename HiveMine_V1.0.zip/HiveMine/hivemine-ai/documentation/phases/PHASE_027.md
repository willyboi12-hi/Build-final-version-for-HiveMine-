# Phase 027 — SecurityAI

## Objective

Audit granted capabilities and redact sensitive text.

## Implementation

modules/SecurityAI.java: Finding; auditGrants(), redact(), containsSensitive().

## Dependencies

BaseSpecialist, PolicySupervisor.isHardDenied.

## Integration

Registered through `ManagerCoordinator` and started with the other Stage 3 modules. Capability `audit.security` is granted through the policy supervisor.

## Testing

SecurityAITests: hard-denied grants, e-mail, secret and card-like redaction, missing input.

## Completion criteria

- Module reports AVAILABLE after start.
- Capability `audit.security` is grantable and usable through a task.
- Unit checks pass in `tests/run.sh`.

## Notes

Audits and redacts only; grants and revokes nothing.

## Safety boundary

Analysis, configuration or reporting only. The module performs no game or device action.
