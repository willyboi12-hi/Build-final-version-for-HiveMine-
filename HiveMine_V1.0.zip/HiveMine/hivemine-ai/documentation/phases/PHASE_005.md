# Phase 005 — Manager Communication

## Scope

Phase 005 gives AI modules a way to send each other messages through HiveMineManagerAI. Messages are plain text and are never executed by the receiver. Delivery is pull-based: a module reads its own mailbox when it chooses to.

## Added classes

- `comm/AIMessage` — immutable message: sequence number, sender, recipient, type, read-only text payload, send time.
- `comm/MessageBus` — registered addresses, one bounded mailbox per address, `send`, `drain`, `pending`, and counters.
- `Identifiers` — the shared identifier rule used by modules, addresses, message types, scopes and capabilities.

## Rules

- Sender and recipient must be registered addresses, and they must differ.
- Message types and identifiers must match the identifier rule.
- A payload holds at most 16 entries; keys and values are at most 512 characters.
- A full mailbox refuses the new message. Older mail is never dropped silently.
- Payloads are copied on send and exposed read-only.
- Through `ManagerCoordinator`, messages are accepted only while the manager is RUNNING.

## Validation

Covered by `MessagingTests` (sequencing, validation, limits, drain order, unregister, counters) and by the coordinator tests.

## Safety boundary

Messages carry information between AI modules. They cannot grant permissions or trigger game input.
