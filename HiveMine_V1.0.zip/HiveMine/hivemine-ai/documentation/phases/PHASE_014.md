# Phase 014 — NavigationAI

## Objective

Compare observed location with a planned route.

## Implementation

modules/NavigationAI.java: Status, Assessment; assess().

## Dependencies

BaseSpecialist. Depends on state.

## Integration

Reports ON_ROUTE, OFF_ROUTE, LOST, COMPLETE or UNKNOWN. Issues no movement commands.

## Testing

NavigationAITests: route progress, unrecognised frames, off-route, lost, recovery, validation.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `analyze.location` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Route status is derived from recognised fields only.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
