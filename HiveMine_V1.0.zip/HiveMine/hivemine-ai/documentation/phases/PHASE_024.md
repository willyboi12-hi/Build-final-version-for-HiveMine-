# Phase 024 — StrategyAI

## Objective

Rank strategies by weighted scores over named criteria.

## Implementation

modules/StrategyAI.java: Criterion, Option, Scored; rank().

## Dependencies

BaseSpecialist, Identifiers. Depends on analytics.

## Integration

Registered through `ManagerCoordinator` and started with the other Stage 3 modules. Capability `analyze.strategy` is granted through the policy supervisor.

## Testing

StrategyAITests: weighted ranking, missing scores, validation of weights and scores.

## Completion criteria

- Module reports AVAILABLE after start.
- Capability `analyze.strategy` is grantable and usable through a task.
- Unit checks pass in `tests/run.sh`.

## Notes

A missing score counts as zero and the gap is reported.

## Safety boundary

Analysis, configuration or reporting only. The module performs no game or device action.
