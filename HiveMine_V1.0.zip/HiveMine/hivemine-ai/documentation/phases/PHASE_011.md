# Phase 011 — VisionAI

## Objective

Recognise Bee Swarm interface elements in captured frames.

## Implementation

modules/VisionAI.java: Frame, Region, Signature, Detection; recognize(), matchRatio(), readGauge().

## Dependencies

BaseSpecialist, Identifiers. Reads pixels only from frames the app layer captured with user permission.

## Integration

Consumed by StateAI and InventoryAI (depend on vision). Signatures and gauges are configured by the app layer.

## Testing

VisionAITests: colour matching, tolerance, out-of-frame regions, gauge percentages, frame validation.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `observe.frame` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Recognises configured elements with a match confidence; never captures the screen itself. OCR is not included yet.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
