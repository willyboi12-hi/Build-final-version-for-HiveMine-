# Phase 017 — PredictionAI

## Objective

Forecast resource fill times and projected values.

## Implementation

modules/PredictionAI.java: Point, Fit, Forecast; fit(), timeToTarget(), projectValue().

## Dependencies

BaseSpecialist. Depends on farming.

## Integration

Least-squares fit on the latest rise. Confidence grows with readings and fit quality.

## Testing

PredictionAITests: exact and noisy fits, drop handling, flat series, projection, validation.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `analyze.forecast` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Returns no estimate when readings are insufficient or flat.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
