# Phase 093 — HiveMine contract

Domain: INTEGRATION
Implementor (per index): `com.hiveminemobile.ai.integration.EndToEndSimulation`

## What it covers
- Phase 093 — Documented expectations for the HiveMine merge (no Android types).

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/integration/HiveMineContract.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/IntegrationTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
