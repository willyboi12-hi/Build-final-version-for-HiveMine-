# Phase 037 — Model Router

Status: IMPLEMENTED. JVM-tested. Not run on a device.

## Objective

Selects the cheapest registered model that meets a required accuracy for a capability.

## Implementation

`ai-core/src/main/java/com/hiveminemobile/ai/shared/ModelRouter.java`

## Testing

ModelRouterTests (5 checks). Suite total at this phase: 486 passed, 0 failed.

## Notes

Accuracy is a declared figure, not a measured one. Measured figures require the testing stages.

## Safety boundary

Shared infrastructure only. No module in this phase acts on the game or the device.
