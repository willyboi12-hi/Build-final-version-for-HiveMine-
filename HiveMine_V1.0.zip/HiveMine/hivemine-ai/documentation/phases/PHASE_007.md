# Phase 007 — Priority Intelligence

## Scope

Phase 007 ranks pending tasks by importance so the manager works on the most useful task first, without letting any task starve.

## Added classes

- `task/PriorityScorer` — deterministic score and ranking.

## Scoring

`score = priority × 100 + category points + waiting points − retry penalty`

- Priority: LOW 1, NORMAL 2, HIGH 3, CRITICAL 4 (× 100).
- Category: RECOVERY 40, OBSERVATION 20, ANALYSIS 10, MAINTENANCE 0.
- Waiting: one point per minute since creation, capped at 60.
- Retry penalty: 10 per failed attempt, capped at 30, so broken work does not keep jumping the queue.
- Times dated in the future give no negative waiting points.

Ties are broken by older creation time, then by task id, so the ranking is repeatable.

## Use

`TaskManager.nextPending(now, limit)` returns the top pending tasks. `ManagerCoordinator.nextTasks` exposes the same ranking.

## Validation

Covered by `PriorityTests`: band ordering, waiting bonus and its cap, future-dated tasks, retry penalties, ranking, and exclusion of assigned tasks.

## Safety boundary

The score only orders work. It does not change who may do it.
