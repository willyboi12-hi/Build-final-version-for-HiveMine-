# Overlaps between the spec and existing code

The reconstructed spec and the code from earlier phases use some of the same names and jobs. Nothing was merged or deleted. Each overlap is listed here so a reader knows which class to use.

| Phase(s) | New class (this work) | Existing class with a similar job | Status |
|---|---|---|---|
| 081 | `history.HistoricalPerformanceAnalyzer` | `optimize.PerformanceProfiler`, `optimize.PerfSample` | Both exist. The new one reads decision history. The old one reads timing samples. |
| 084 | `tuning.AIOptimizationManager` | `optimize.OptimizationEngine`, `optimize.ResourceBudget` | Both exist. The new one only recommends. The old one may act. |
| 085, 086 | `android.AndroidIntegrationManager`, `android.AndroidLifecycleController` | `integration.LifecycleIntegrator`, `integration.IntegrationManifest` | Both exist. Nothing has been checked to see whether they conflict at runtime. |
| 089 | `android.AndroidMacroCommunicationBridge` | `integration.IntegrationBus`, `comm.*`, `communication.*` | Both exist. Only the new one is wired to the app. |
| 090 | `android.AndroidConfigurationSyncManager` | `integration.ConfigBridge` | Both exist. Only the new one has backups and conflict checks. |

Open question: should the old classes be retired or merged into the new ones? That is a product decision, and the code has not been changed for it.
