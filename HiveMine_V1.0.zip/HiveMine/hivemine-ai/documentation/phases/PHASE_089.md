# Phase 089 — Android macro communication bridge

Domain: ANDROID

## Status
Implemented in JVM code and tested (checks in `tests/unit/com/hiveminemobile/Phases081To090Tests.java`). Not run on an Android device.

## What it does
Sends START, STOP, or RECOVER through `MacroPort`. A request is ACCEPTED when sent to a connected macro and COMPLETED only when the macro state confirms it. Duplicate pending commands are prevented, and unconfirmed requests time out.

## API
- `send`, `observe(status, now)`, `requests()`.

## Not done
- Wired: `AiControlHub.bridge()` sends commands through `AiMacroPort` to the real `MacroAccessibilityService`. Tested with the fake service in `AndroidWiringChecks`.
- The dashboard's Start/Recover/Stop buttons still call `AutomationController` directly, not this bridge. Moving them over is a later change.
- Not device-tested: real macro timing. The 15-second timeout is a guess.
