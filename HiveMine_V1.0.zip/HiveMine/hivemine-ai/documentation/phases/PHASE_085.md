# Phase 085 — Android integration manager

Domain: ANDROID

## Status
Implemented in JVM code and tested (checks in `tests/unit/com/hiveminemobile/Phases081To090Tests.java`). Not run on an Android device.

## What it does
Tracks whether required Android components (macro-port, accessibility-service, configuration-storage) are available. UNKNOWN is never treated as available.

## API
- `register`, `update`, `statusOf`, `missing()`, `canInitialize()`.

## Not done
- Wired: `AiControlHub.integration(Context)` refreshes the three components from the real service binding and prefs. The AI tab shows the result.
- Not device-tested: whether the service is bound on a real phone.
- Overlap with existing code: see `OVERLAPS.md`.
