# Phase 020 — DiagnosticsAI

## Objective

Diagnose component, error and messaging problems.

## Implementation

modules/DiagnosticsAI.java: Severity, Diagnostic; diagnose().

## Dependencies

BaseSpecialist, HealthMonitor (Phase 010), AIErrorHandler.

## Integration

Diagnoses only; it repairs nothing. Findings are sorted most severe first.

## Testing

DiagnosticsAITests: unavailable and degraded components, critical errors, rejections, stale values, ordering.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `analyze.diagnostics` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Reports one finding per problem, or a single all-clear.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
