# Phase 023 — SessionAI

## Objective

Track automation sessions with a bounded history and a summary.

## Implementation

modules/SessionAI.java: Session, Outcome, Report; start(), end(), report().

## Dependencies

BaseSpecialist.

## Integration

Registered through `ManagerCoordinator` and started with the other Stage 3 modules. Capability `analyze.session` is granted through the policy supervisor.

## Testing

SessionAITests: single running session, durations, reports, id reuse, time order, history limit.

## Completion criteria

- Module reports AVAILABLE after start.
- Capability `analyze.session` is grantable and usable through a task.
- Unit checks pass in `tests/run.sh`.

## Notes

One running session at a time. Ids are unique. History keeps the newest closed sessions.

## Safety boundary

Analysis, configuration or reporting only. The module performs no game or device action.
