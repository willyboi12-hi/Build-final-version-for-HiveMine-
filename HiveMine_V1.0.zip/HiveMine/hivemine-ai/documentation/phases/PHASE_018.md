# Phase 018 — RecoveryAI

## Objective

Turn recent errors into a recovery plan that needs approval.

## Implementation

modules/RecoveryAI.java: ErrorKind, ErrorEvent, Plan, Step; plan().

## Dependencies

BaseSpecialist. Depends on state.

## Integration

Every plan requires approval. Refused inputs and repeated errors escalate to SAFE_STOP and ASK_USER.

## Testing

RecoveryAITests: severity levels, escalation, window handling, future events, validation.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `plan.recovery` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Plans are recommendations only; the module performs no steps.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
