# Phase 095 — Config bridge

Domain: INTEGRATION
Implementor (per index): `com.hiveminemobile.ai.integration.EndToEndSimulation`

## What it covers
- Phase 095 — Name-level bridge between AI settings and macro setting keys.

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/integration/ConfigBridge.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/IntegrationTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
