# Phase 086 — Android lifecycle controller

Domain: ANDROID

## Status
Implemented in JVM code and tested (checks in `tests/unit/com/hiveminemobile/Phases081To090Tests.java`). Not run on an Android device.

## What it does
Starts and stops the AI. Refuses duplicate starts and starts when integration is not ready. Records interruptions and restores saved state only when the integration is ready.

## API
- `start`, `stop`, `interrupt`, `persist`, `restoreAfterRestart`.

## Not done
- Not wired to the dashboard. The JVM logic is tested, not the app.
- Overlap with existing code: see `OVERLAPS.md`.
