# Phase 025 — MovementAI specialist system

Domain: `SPECIALIST`

## Requirement
Unique phase implementation for **MovementAI specialist system** in the HiveMineAI 250-phase program.

## Implementation
- Catalog entry: `PhaseCatalog.get(25)`
- Primary implementor: `com.hiveminemobile.ai.merge.SpecialistCatalogFactory`
- Verified via: `PhaseExecutor.verify(25)`

## Status
IMPLEMENTED (JVM). Device verification UNVERIFIED unless noted elsewhere.

## Acceptance
- Catalog lists this phase as IMPLEMENTED
- PhaseExecutor returns ok for phase 25
- No empty placeholder-only specialist for specialist-domain phases
