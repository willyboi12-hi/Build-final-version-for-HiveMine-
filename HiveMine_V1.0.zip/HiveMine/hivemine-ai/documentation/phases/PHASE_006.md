# Phase 006 — Global Task Management

## Scope

Phase 006 lets HiveMineManagerAI create, assign and track units of work. A task names a capability that a specialist must offer. Tasks describe analysis or observation; they carry no input, gesture or device command.

## Added classes

- `task/Task` — immutable snapshot: id, title, capability, priority, category, status, assignee, attempts, note, timestamps.
- `task/TaskStatus`, `task/Priority`, `task/TaskCategory` — lifecycle and classification enums.
- `task/AssignmentGate` — decides whether a specialist may take a task (`ALLOW_ALL` by default).
- `task/TaskManager` — create, assign, start, complete, fail, cancel, list, load, and open-task limit.

## Lifecycle

`PENDING → ASSIGNED → IN_PROGRESS → COMPLETED`. A failed attempt returns the task to `PENDING` while attempts remain; the final failure ends in `FAILED`. `CANCELLED` is allowed from any open state.

## Assignment rules

- Only registered specialists offering the capability are candidates.
- `UNAVAILABLE` and `FAILED` specialists are never candidates.
- Candidates are ordered: fully available before degraded, then least loaded, then registration order.
- The gate can refuse a candidate; the next candidate is tried.
- Only the assigned specialist can start, complete, or fail its task.

## Validation

Covered by `TaskTests`: creation checks, load balancing, unavailable specialists, the open-task limit, the retry cycle, actor checks, gate refusals, cancellation, and lookups.

## Safety boundary

Assignment selects a module to analyse or observe. It does not grant that module any permission; the policy gate from Phase 009 decides what may run.
