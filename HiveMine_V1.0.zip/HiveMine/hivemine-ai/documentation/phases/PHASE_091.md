# Phase 091 — Integration manifest

Domain: INTEGRATION
Implementor (per index): `com.hiveminemobile.ai.integration.EndToEndSimulation`

## What it covers
- Phase 091 — Declares which integration components are present.

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/integration/IntegrationManifest.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/IntegrationTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
