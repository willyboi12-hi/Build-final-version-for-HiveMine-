# Phase 021 — PerformanceAI

## Objective

Summarise CPU, memory and battery samples against limits.

## Implementation

modules/PerformanceAI.java: Sample, Report; analyze().

## Dependencies

BaseSpecialist. Observes only.

## Integration

Registered through `ManagerCoordinator` and started with the other Stage 3 modules. Capability `analyze.performance` is granted through the policy supervisor.

## Testing

PerformanceAITests: averages, peaks, each limit, empty and invalid samples.

## Completion criteria

- Module reports AVAILABLE after start.
- Capability `analyze.performance` is grantable and usable through a task.
- Unit checks pass in `tests/run.sh`.

## Notes

Feeds Diagnostics findings through the health report; changes no setting.

## Safety boundary

Analysis, configuration or reporting only. The module performs no game or device action.
