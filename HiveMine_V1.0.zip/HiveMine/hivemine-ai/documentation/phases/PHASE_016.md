# Phase 016 — QuestAI

## Objective

Track quest objectives and detect stalled progress.

## Implementation

modules/QuestAI.java: Status, Assessment; observe().

## Dependencies

BaseSpecialist. Depends on vision.

## Integration

Quest lines are parsed as '<giver>: <objective> <current>/<target>'.

## Testing

QuestAITests: parsing, progress, stall detection, completion, resets, invalid lines.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `analyze.quest` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Reports IN_PROGRESS, COMPLETE, STALLED or UNREADABLE per quest.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
