# Phase 026 — NotificationAI

## Objective

Deliver alerts with de-duplication and rate limiting.

## Implementation

modules/NotificationAI.java: Level, Decision, Alert; notify(), inbox().

## Dependencies

BaseSpecialist.

## Integration

Registered through `ManagerCoordinator` and started with the other Stage 3 modules. Capability `report.notify` is granted through the policy supervisor.

## Testing

NotificationAITests: de-duplication, rate limiting, critical bypass, ordering, validation.

## Completion criteria

- Module reports AVAILABLE after start.
- Capability `report.notify` is grantable and usable through a task.
- Unit checks pass in `tests/run.sh`.

## Notes

Critical alerts skip the rate limit, not de-duplication. Inbox keeps the newest 100.

## Safety boundary

Analysis, configuration or reporting only. The module performs no game or device action.
