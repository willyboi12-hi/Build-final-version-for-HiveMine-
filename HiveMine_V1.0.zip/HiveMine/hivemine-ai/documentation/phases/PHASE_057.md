# Phase 057 — Quest Prioritization

Status: IMPLEMENTED (JVM-tested). Real-game validity UNVERIFIED: nothing here has been run against the game or a device.

## Objective

Ranks objectives by reward per remaining unit, doubled when due within 30 minutes.

## Implementation

`ai-core/src/main/java/com/hiveminemobile/ai/farming/QuestPrioritizer.java`

## Testing

QuestPrioritizerTests (3 checks). Suite total at this phase: 583 passed, 0 failed. Mutation checks on three modules were caught by the tests.

## Notes

The score is a stated heuristic, not a measured optimum.

## Safety boundary

Analysis and reporting only. Nothing here starts, stops or changes the macro.
