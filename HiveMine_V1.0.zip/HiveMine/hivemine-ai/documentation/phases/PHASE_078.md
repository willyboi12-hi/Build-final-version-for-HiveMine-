# Phase 078 — Intelligence loop

Domain: MANAGER_INTEL
Implementor (per index): `com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop`

## What it covers
- Phase 078 — One intelligence step: policy + votes + fusion + conflict + escalation

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/manager/intel/ManagerIntelligenceLoop.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/ManagerIntelligenceTests.java`
- `hivemine-ai/tests/unit/com/hiveminemobile/PhasePowerTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
