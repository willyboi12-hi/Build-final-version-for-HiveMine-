package com.hiveminemobile.ai.phases;

import com.hiveminemobile.ai.decision.PowerDecisionEngine;
import com.hiveminemobile.ai.merge.SpecialistCatalogFactory;
import com.hiveminemobile.ai.modules.BaseSpecialist;
import com.hiveminemobile.ai.modules.SignalIntelligence;
import com.hiveminemobile.ai.subsystems.PhaseSubsystemRegistry;
import com.hiveminemobile.ai.subsystems.Subsystem;

import java.util.HashMap;
import java.util.List;

/** Executes lightweight verification for any phase number 1-250. */
public final class PhaseExecutor {
    public static final class Result {
        public final int phase;
        public final boolean ok;
        public final String detail;
        public Result(int phase, boolean ok, String detail) {
            this.phase = phase; this.ok = ok; this.detail = detail == null ? "" : detail;
        }
    }

    public Result verify(int phaseNumber) {
        PhaseCatalog.Phase p = PhaseCatalog.get(phaseNumber);
        if (p == null) return new Result(phaseNumber, false, "unknown phase");
        try {
            if ("SPECIALIST".equals(p.domain) || "SPECIALIST_DEPTH".equals(p.domain)) {
                List<BaseSpecialist> all = new SpecialistCatalogFactory().all();
                if (all.size() < 20) return new Result(phaseNumber, false, "specialists not implemented: " + all.size() + " of 20 working");
            }
            if ("MANAGER_INTEL".equals(p.domain) || "MANAGER".equals(p.domain)) {
                PowerDecisionEngine eng = new PowerDecisionEngine();
                PowerDecisionEngine.Factors f = new PowerDecisionEngine.Factors();
                f.userWantsFarm = true;
                f.pollenRate = 0.8;
                if (eng.decide(f, null) == null) return new Result(phaseNumber, false, "no decision");
            }
            if ("DATA".equals(p.domain)) {
                HashMap<String, Double> m = new HashMap<String, Double>();
                m.put("a", 1.0);
                m.put("b", 2.0);
                if (SignalIntelligence.rankedKeys(m).isEmpty()) return new Result(phaseNumber, false, "rank empty");
            }
            // Phases 101-250 have explicit lightweight subsystem implementations. Verify
            // those implementations directly instead of pretending the legacy shared
            // implementor-class strings are independently executable phase classes.
            if (phaseNumber >= 101 && phaseNumber <= 250) {
                Subsystem subsystem = PhaseSubsystemRegistry.create(phaseNumber);
                if (subsystem == null) return new Result(phaseNumber, false, "no subsystem registered");
                if (subsystem.phaseNumber() != phaseNumber) return new Result(phaseNumber, false, "phase number mismatch");
                if (!p.domain.equals(subsystem.domain())) return new Result(phaseNumber, false, "domain mismatch: " + subsystem.domain());
                if (subsystem.evaluate(null) == null || subsystem.evaluate(null).isEmpty())
                    return new Result(phaseNumber, false, "subsystem evaluation empty");
                if (Double.isNaN(subsystem.health()) || Double.isInfinite(subsystem.health()) || subsystem.health() < 0.0 || subsystem.health() > 1.0)
                    return new Result(phaseNumber, false, "invalid subsystem health");
                return new Result(phaseNumber, true, p.name);
            }
            Class.forName(p.implementorClass);
            return new Result(phaseNumber, true, p.name);
        } catch (ClassNotFoundException e) {
            return new Result(phaseNumber, false, "missing " + p.implementorClass);
        } catch (Throwable t) {
            return new Result(phaseNumber, false, t.getClass().getSimpleName());
        }
    }

    public int verifyAll() {
        int ok = 0;
        for (int i = 1; i <= 250; i++) if (verify(i).ok) ok++;
        return ok;
    }
}
