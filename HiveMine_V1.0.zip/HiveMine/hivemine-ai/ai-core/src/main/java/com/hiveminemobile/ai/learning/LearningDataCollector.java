package com.hiveminemobile.ai.learning;

import com.hiveminemobile.ai.memory.DecisionRecord;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Keeps only records that can be learned from. Incomplete records are counted, not silently dropped. */
public final class LearningDataCollector {

    public static final class Collected {
        public final List<DecisionRecord> valid;
        public final int rejected;

        Collected(List<DecisionRecord> valid, int rejected) {
            this.valid = Collections.unmodifiableList(valid);
            this.rejected = rejected;
        }
    }

    public Collected collect(List<DecisionRecord> history) {
        List<DecisionRecord> valid = new ArrayList<>();
        int rejected = 0;
        if (history != null) {
            for (DecisionRecord r : history) {
                if (r == null || r.getOutcome() == null || isBlank(r.getCapability()) || isBlank(r.getDecision())) {
                    rejected++;
                } else {
                    valid.add(r);
                }
            }
        }
        return new Collected(valid, rejected);
    }

    private static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
}
