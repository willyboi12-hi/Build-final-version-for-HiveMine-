package com.hiveminemobile.ai.learning;

import java.util.HashMap;
import java.util.Map;
import java.util.OptionalDouble;

/** Records whether applied recommendations actually improved results. */
public final class LearningResultEvaluator {
    private final Map<String, int[]> counts = new HashMap<>(); // [improved, notImproved]

    public synchronized void record(String recommendationId, boolean improved) {
        int[] c = counts.get(recommendationId);
        if (c == null) { c = new int[2]; counts.put(recommendationId, c); }
        if (improved) c[0]++; else c[1]++;
    }

    public synchronized OptionalDouble improvementRate(String recommendationId) {
        int[] c = counts.get(recommendationId);
        if (c == null || c[0] + c[1] == 0) return OptionalDouble.empty();
        return OptionalDouble.of((double) c[0] / (c[0] + c[1]));
    }
}
