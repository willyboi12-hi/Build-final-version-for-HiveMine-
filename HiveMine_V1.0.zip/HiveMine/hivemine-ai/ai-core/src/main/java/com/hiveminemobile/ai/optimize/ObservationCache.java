package com.hiveminemobile.ai.optimize;
/** Phase 085 — Tiny TTL cache for observation snapshots. */
public final class ObservationCache<T> {
    private T value;
    private long storedAtMs = -1;
    private final long ttlMs;
    public ObservationCache(long ttlMs) { this.ttlMs = Math.max(0, ttlMs); }
    public void put(T v, long nowMs) {
        if (nowMs < 0L) { clear(); return; }
        value = v; storedAtMs = nowMs;
    }
    public T get(long nowMs) {
        if (storedAtMs < 0L || nowMs < 0L || nowMs < storedAtMs) return null;
        if (nowMs - storedAtMs > ttlMs) return null;
        return value;
    }
    public void clear() { value = null; storedAtMs = -1; }
}
