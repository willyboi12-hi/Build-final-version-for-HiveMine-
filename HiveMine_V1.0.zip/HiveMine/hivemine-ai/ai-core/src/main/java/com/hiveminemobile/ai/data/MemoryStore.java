package com.hiveminemobile.ai.data;
import java.util.HashMap;
import java.util.Map;
/** Phase 101–110 data: in-memory key store for AI session data. */
public final class MemoryStore {
    private final HashMap<String, String> map = new HashMap<String, String>();
    public synchronized void put(String k, String v) { if (k != null) map.put(k, v); }
    public synchronized String get(String k) { return map.get(k); }
    public synchronized boolean contains(String k) { return map.containsKey(k); }
    public synchronized void clear() { map.clear(); }
    public synchronized int size() { return map.size(); }
    public synchronized Map<String, String> snapshot() { return new HashMap<String, String>(map); }
}
