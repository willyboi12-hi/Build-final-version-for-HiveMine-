package com.hiveminemobile.ai.loot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * BSS Blender recipes (community guides / wiki-aligned).
 * Used to plan field farming for ingredients — does not operate the in-game blender.
 */
public final class BlenderCatalog {

    public static final class Ingredient {
        public final String name;
        public final int amount;
        public Ingredient(String name, int amount) {
            this.name = name;
            this.amount = amount;
        }
        @Override public String toString() { return amount + "x " + name; }
    }

    public static final class Recipe {
        public final String id;
        public final String displayName;
        public final List<Ingredient> ingredients;
        public final String farmField; // primary HiveMine field to gather ingredients
        public final List<String> altFields;
        public final String tip;

        public Recipe(String id, String displayName, List<Ingredient> ingredients,
                      String farmField, List<String> altFields, String tip) {
            this.id = id;
            this.displayName = displayName;
            this.ingredients = ingredients;
            this.farmField = farmField;
            this.altFields = altFields;
            this.tip = tip;
        }
    }

    private static final LinkedHashMap<String, Recipe> RECIPES = new LinkedHashMap<String, Recipe>();

    static {
        add("gumdrops", "Gumdrops",
                ings(ing("Pineapples", 3), ing("Strawberries", 3), ing("Blueberries", 3)),
                "Pineapple", list("Strawberry", "Blue Flower"),
                "Craft gumdrops then glue. Or buy gumdrops with tickets.");
        add("red_extract", "Red Extract",
                ings(ing("Royal Jelly", 10), ing("Strawberries", 50)),
                "Strawberry", list("Pepper", "Rose"),
                "Farm strawberries then blend. Used in red gear and potions.");
        add("blue_extract", "Blue Extract",
                ings(ing("Royal Jelly", 10), ing("Blueberries", 50)),
                "Blue Flower", list("Pine Tree", "Stump"),
                "Farm blueberries then blend. Used in blue gear.");
        add("enzymes", "Enzymes",
                ings(ing("Royal Jelly", 10), ing("Pineapples", 50)),
                "Pineapple", list("Pumpkin", "Pine Tree"),
                "Core craft mat for masks/waxes. Pineapple field first.");
        add("oil", "Oil",
                ings(ing("Royal Jelly", 10), ing("Sunflower Seeds", 50)),
                "Sunflower", list("Dandelion", "Mushroom"),
                "Farm sunflower seeds then blend.");
        add("glue", "Glue",
                ings(ing("Royal Jelly", 10), ing("Gumdrops", 50)),
                "Spider", list("Strawberry", "Pineapple", "Blue Flower"),
                "Need 50 gumdrops each. Farm fruit fields for gumdrop craft, or tickets.");
        add("moon_charm", "Moon Charm",
                ings(ing("Royal Jelly", 1), ing("Pineapples", 5), ing("Gumdrops", 5)),
                "Pineapple", list("Spider", "Strawberry"),
                "Used for glitter and amulets.");
        add("glitter", "Glitter",
                ings(ing("Moon Charms", 25), ing("Magic Bean", 1)),
                "Pine Tree", list("Spider", "Mountain Top"),
                "Needs moon charms + magic bean. Token/sprout heavy play helps.");
        add("tropical_drink", "Tropical Drink",
                ings(ing("Coconuts", 10), ing("Enzymes", 2), ing("Oil", 2)),
                "Coconut", list("Pepper", "Mountain Top"),
                "Coconut field is jump-heavy; expect more route drift.");
        add("soft_wax", "Soft Wax",
                ings(ing("Honeysuckles", 5), ing("Oil", 1), ing("Enzymes", 1), ing("Royal Jelly", 10)),
                "Sunflower", list("Pineapple", "Clover"),
                "Craft oil+enzymes first, then soft wax. Also from planters/puffshrooms.");
        add("hard_wax", "Hard Wax",
                ings(ing("Soft Waxes", 3), ing("Enzymes", 3), ing("Bitterberries", 33), ing("Royal Jelly", 33)),
                "Pepper", list("Mountain Top", "Pine Tree"),
                "Late mat. Farm enzymes + soft wax chain.");
        add("star_jelly", "Star Jelly",
                ings(ing("Royal Jelly", 100), ing("Glitter", 3)),
                "Pine Tree", list("Spider", "Mountain Top"),
                "Expensive RJ sink. Plan glitter first.");
        add("purple_potion", "Purple Potion",
                ings(ing("Neonberries", 3), ing("Red Extracts", 3), ing("Blue Extracts", 3), ing("Glues", 3)),
                "Pepper", list("Strawberry", "Blue Flower", "Mountain Top"),
                "Needs both extracts + glue. Multi-field farming.");
        add("field_dice", "Field Dice",
                ings(ing("Soft Wax", 1), ing("Whirligig", 1), ing("Red Extract", 1), ing("Blue Extract", 1)),
                "Strawberry", list("Blue Flower", "Sunflower"),
                "Utility craft from extracts + soft wax.");
        add("smooth_dice", "Smooth Dice",
                ings(ing("Field Dice", 3), ing("Soft Waxes", 3), ing("Whirligigs", 3), ing("Oils", 3)),
                "Sunflower", list("Strawberry", "Blue Flower"),
                "Higher dice tier.");
        add("loaded_dice", "Loaded Dice",
                ings(ing("Smooth Dice", 3), ing("Hard Waxes", 3), ing("Oils", 3), ing("Glue", 1)),
                "Pine Tree", list("Pepper", "Spider"),
                "Endgame dice craft.");
        add("caustic_wax", "Caustic Wax",
                ings(ing("Hard Waxes", 5), ing("Enzymes", 5), ing("Neonberries", 25), ing("Royal Jelly", 5252)),
                "Pepper", list("Mountain Top", "Coconut"),
                "Very expensive. Prefer drops when possible.");
        add("swirled_wax", "Swirled Wax",
                ings(ing("Hard Waxes", 3), ing("Soft Waxes", 9), ing("Purple Potions", 6), ing("Royal Jelly", 3333)),
                "Pepper", list("Mountain Top", "Pine Tree"),
                "Endgame wax.");
        add("super_smoothie", "Super Smoothie",
                ings(ing("Neonberries", 3), ing("Star Jellies", 3), ing("Purple Potions", 3), ing("Tropical Drinks", 6)),
                "Coconut", list("Pepper", "Mountain Top"),
                "Deep craft chain.");
        add("turpentine", "Turpentine",
                ings(ing("Super Smoothies", 10), ing("Caustic Waxes", 10), ing("Star Jellies", 100), ing("Honeysuckles", 1000)),
                "Coconut", list("Pepper", "Mountain Top"),
                "Top-end material. Mostly not pure field macro.");
    }

    private static Ingredient ing(String n, int a) { return new Ingredient(n, a); }
    private static List<Ingredient> ings(Ingredient... x) {
        ArrayList<Ingredient> l = new ArrayList<Ingredient>();
        for (Ingredient i : x) l.add(i);
        return Collections.unmodifiableList(l);
    }
    private static List<String> list(String... x) {
        ArrayList<String> l = new ArrayList<String>();
        for (String s : x) l.add(s);
        return Collections.unmodifiableList(l);
    }
    private static void add(String id, String name, List<Ingredient> ings, String field, List<String> alts, String tip) {
        RECIPES.put(id, new Recipe(id, name, ings, field, alts, tip));
    }

    public static Recipe get(String idOrName) {
        if (idOrName == null) return null;
        String k = idOrName.trim().toLowerCase(Locale.US).replace(' ', '_');
        if (RECIPES.containsKey(k)) return RECIPES.get(k);
        for (Recipe r : RECIPES.values()) {
            if (r.displayName.equalsIgnoreCase(idOrName.trim())) return r;
            if (r.id.replace('_', ' ').equalsIgnoreCase(idOrName.trim())) return r;
        }
        // fuzzy
        for (Recipe r : RECIPES.values()) {
            if (r.displayName.toLowerCase(Locale.US).contains(idOrName.toLowerCase(Locale.US))) return r;
        }
        return null;
    }

    public static List<Recipe> all() {
        return Collections.unmodifiableList(new ArrayList<Recipe>(RECIPES.values()));
    }

    public static List<String> displayNames() {
        ArrayList<String> n = new ArrayList<String>();
        for (Recipe r : RECIPES.values()) n.add(r.displayName);
        return n;
    }

    public static Map<String, Integer> scaleIngredients(Recipe r, int qty) {
        LinkedHashMap<String, Integer> m = new LinkedHashMap<String, Integer>();
        if (r == null || qty < 1) return m;
        for (Ingredient i : r.ingredients) m.put(i.name, i.amount * qty);
        return m;
    }
}
