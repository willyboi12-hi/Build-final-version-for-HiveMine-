package com.hiveminemobile.ai.optimize;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import java.util.ArrayList;
import java.util.List;
/** Phase 089 — Facade over profilers, budget, cache, batching, load shed. */
public final class OptimizationEngine {
    private final OptimizationPolicy policy;
    private final PerformanceProfiler profiler = new PerformanceProfiler();
    private final ResourceBudget budget;
    private final ObservationCache<Object> cache;
    private final BatchDecisionOptimizer batcher = new BatchDecisionOptimizer();
    private final LoadShedder shedder;
    private final CooldownOptimizer cooldowns;
    private final ArrayList<ManagerGoal> recentGoals = new ArrayList<ManagerGoal>();

    public OptimizationEngine(OptimizationPolicy policy) {
        this.policy = policy == null ? new OptimizationPolicy() : policy;
        this.budget = new ResourceBudget(this.policy.budgetPerWindow);
        this.cache = new ObservationCache<Object>(this.policy.observationTtlMs);
        this.shedder = new LoadShedder(this.policy.loadNormal, this.policy.loadHigh);
        this.cooldowns = new CooldownOptimizer(this.policy.cooldownMin, this.policy.cooldownMax);
    }

    public PerformanceProfiler profiler() { return profiler; }
    public ResourceBudget budget() { return budget; }
    public ObservationCache<Object> cache() { return cache; }
    public CooldownOptimizer cooldowns() { return cooldowns; }
    public LoadShedder shedder() { return shedder; }

    public ManagerGoal optimizeGoalStream(ManagerGoal incoming) {
        recentGoals.add(incoming == null ? ManagerGoal.STANDBY : incoming);
        while (recentGoals.size() > 8) recentGoals.remove(0);
        if (!policy.batchDecisions) return recentGoals.get(recentGoals.size() - 1);
        return batcher.collapse(recentGoals);
    }

    public boolean allowWork(LoadShedder.Priority p, double pressure) {
        return shedder.allow(p, pressure);
    }

    public void windowRefill() { budget.refill(); }
}
