package com.hiveminemobile.ai.subsystems;

import java.util.Map;

/** Unique subsystem for phase 060 (FARMING). */
public final class Phase060Subsystem extends AbstractSubsystem {
    public Phase060Subsystem() {
        super(60, "FARMING", "FarmingSubsystem P060");
    }

    @Override
    public Map<String, Double> evaluate(Map<String, Double> input) {
        double pollenRate = get(input, "pollenRate", 0.4);
        double bag = get(input, "bagFill", 0.2);
        double score = pollenRate * (1.0 - bag * 0.5) + (60 % 9) * 0.015;
        setHealth(1.0);
        return out("farmingValue", score);
    }
}
