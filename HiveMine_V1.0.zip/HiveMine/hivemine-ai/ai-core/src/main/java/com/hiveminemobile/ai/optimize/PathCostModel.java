package com.hiveminemobile.ai.optimize;
/** Phase 082 — Estimates relative cost of a field route (lower is better). */
public final class PathCostModel {
    public double cost(double tiles, double jumpsPenalty, double pollenPerMinute) {
        double t = Math.max(0, tiles);
        double j = Math.max(0, jumpsPenalty);
        double ppm = Math.max(0.01, pollenPerMinute);
        return (t + j * 8.0) / ppm;
    }
    public String betterField(String a, double costA, String b, double costB) {
        if (costA <= costB) return a == null ? "" : a;
        return b == null ? "" : b;
    }
}
