package com.hiveminemobile.ai.optimize;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/** Phase 081 — Aggregates named duration samples. */
public final class PerformanceProfiler {
    private final HashMap<String, long[]> stats = new HashMap<String, long[]>(); // [count, total, max]
    public void record(PerfSample s) {
        if (s == null) return;
        long[] a = stats.get(s.name);
        if (a == null) { a = new long[3]; stats.put(s.name, a); }
        a[0]++; a[1] += s.durationMs; if (s.durationMs > a[2]) a[2] = s.durationMs;
    }
    public long count(String name) { long[] a = stats.get(name); return a == null ? 0 : a[0]; }
    public double avgMs(String name) { long[] a = stats.get(name); return a == null || a[0] == 0 ? 0 : (double) a[1] / a[0]; }
    public long maxMs(String name) { long[] a = stats.get(name); return a == null ? 0 : a[2]; }
    public List<String> names() { return new ArrayList<String>(stats.keySet()); }
}
