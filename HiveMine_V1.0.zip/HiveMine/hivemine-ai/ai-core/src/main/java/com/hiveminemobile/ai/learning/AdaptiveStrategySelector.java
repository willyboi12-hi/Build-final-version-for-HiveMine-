package com.hiveminemobile.ai.learning;

import com.hiveminemobile.ai.farming.StrategyPerformanceLedger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Purple pass: evidence-weighted strategy selection.
 *
 * <p>Uses only verified historical strategy runs. It favors strategies with a strong
 * observed pollen/hour rate while applying an uncertainty penalty to tiny samples.
 * It never changes the active strategy; callers receive a recommendation only.</p>
 */
public final class AdaptiveStrategySelector {
    public static final class Candidate {
        public final String strategy;
        public final int evidence;
        public final double meanPollenPerHour;
        public final double standardDeviation;
        public final double score;
        Candidate(String strategy, int evidence, double mean, double sd, double score) {
            this.strategy = strategy; this.evidence = evidence;
            this.meanPollenPerHour = mean; this.standardDeviation = sd; this.score = score;
        }
    }

    public static final class Selection {
        public final String field;
        public final String current;
        public final String recommended;
        public final boolean switchSuggested;
        public final String reason;
        public final List<Candidate> candidates;
        Selection(String field, String current, String recommended, boolean switchSuggested,
                  String reason, List<Candidate> candidates) {
            this.field = field; this.current = current; this.recommended = recommended;
            this.switchSuggested = switchSuggested; this.reason = reason;
            this.candidates = Collections.unmodifiableList(new ArrayList<>(candidates));
        }
    }

    private final int minimumEvidence;
    private final double switchMargin;

    public AdaptiveStrategySelector(int minimumEvidence, double switchMargin) {
        if (minimumEvidence < 2 || switchMargin < 0) throw new IllegalArgumentException("invalid selector bounds");
        this.minimumEvidence = minimumEvidence;
        this.switchMargin = switchMargin;
    }

    public Selection select(String field, String current, List<StrategyPerformanceLedger.Run> runs) {
        if (blank(field) || blank(current) || runs == null) {
            return empty(field, current, "Insufficient strategy evidence");
        }
        Map<String, List<Double>> values = new LinkedHashMap<>();
        for (StrategyPerformanceLedger.Run run : runs) {
            if (run != null && run.isVerified() && field.equalsIgnoreCase(run.getField())) {
                List<Double> list = values.get(run.getStrategy());
                if (list == null) { list = new ArrayList<>(); values.put(run.getStrategy(), list); }
                list.add(run.getPollenPerHour());
            }
        }
        List<Candidate> candidates = new ArrayList<>();
        for (Map.Entry<String,List<Double>> entry : values.entrySet()) {
            if (entry.getValue().size() < minimumEvidence) continue;
            double mean = mean(entry.getValue());
            double sd = standardDeviation(entry.getValue(), mean);
            double uncertainty = sd / Math.sqrt(entry.getValue().size());
            double score = mean - uncertainty;
            candidates.add(new Candidate(entry.getKey(), entry.getValue().size(), mean, sd, score));
        }
        if (candidates.isEmpty()) return empty(field, current, "Need at least " + minimumEvidence + " verified runs per candidate strategy");
        Collections.sort(candidates, new Comparator<Candidate>() {
            public int compare(Candidate a, Candidate b) { return Double.compare(b.score, a.score); }
        });
        Candidate best = candidates.get(0);
        Candidate currentCandidate = null;
        for (Candidate c : candidates) if (c.strategy.equalsIgnoreCase(current)) { currentCandidate = c; break; }
        if (currentCandidate == null) {
            return new Selection(field, current, current, false,
                "Current strategy has insufficient verified evidence; keep it until evidence is available", candidates);
        }
        boolean change = !best.strategy.equalsIgnoreCase(current)
            && best.score >= currentCandidate.score * (1.0 + switchMargin);
        return new Selection(field, current, change ? best.strategy : current, change,
            change ? "Evidence-weighted score supports a switch"
                   : "Keep current strategy; uncertainty-adjusted evidence is not strong enough to switch", candidates);
    }

    private Selection empty(String field, String current, String reason) {
        return new Selection(field == null ? "" : field, current == null ? "" : current,
            current == null ? "" : current, false, reason, Collections.<Candidate>emptyList());
    }
    private static double mean(List<Double> v) { double s=0; for(double x:v)s+=x; return s/v.size(); }
    private static double standardDeviation(List<Double> v, double mean) {
        if (v.size() < 2) return 0;
        double s=0; for(double x:v){double d=x-mean;s+=d*d;} return Math.sqrt(s/(v.size()-1));
    }
    private static boolean blank(String s){return s==null||s.trim().isEmpty();}
}
