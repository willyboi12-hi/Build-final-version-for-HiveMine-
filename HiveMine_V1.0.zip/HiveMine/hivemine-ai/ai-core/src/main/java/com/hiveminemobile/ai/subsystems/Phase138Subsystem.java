package com.hiveminemobile.ai.subsystems;

import java.util.Map;

/** Unique subsystem for phase 138 (SPECIALIST_DEPTH). */
public final class Phase138Subsystem extends AbstractSubsystem {
    public Phase138Subsystem() {
        super(138, "SPECIALIST_DEPTH", "SpecialistDepthSubsystem P138");
    }

    @Override
    public Map<String, Double> evaluate(Map<String, Double> input) {
        double depth = get(input, "depth", 0.5);
        double novelty = get(input, "novelty", 0.2);
        double score = depth * 0.75 + novelty * 0.25 + (138 % 13) * 0.01;
        setHealth(depth);
        return out("depthScore", score);
    }
}
