package com.hiveminemobile.ai.subsystems;

import java.util.HashMap;
import java.util.Map;

public abstract class AbstractSubsystem implements Subsystem {
    private final int phase;
    private final String domain;
    private final String name;
    private double health = 1.0;

    protected AbstractSubsystem(int phase, String domain, String name) {
        this.phase = phase; this.domain = domain; this.name = name;
    }
    @Override public int phaseNumber() { return phase; }
    @Override public String id() { return "phase-" + phase; }
    @Override public String domain() { return domain; }
    @Override public String name() { return name; }
    @Override public double health() { return health; }
    protected void setHealth(double h) { if (Double.isNaN(h) || Double.isInfinite(h)) h = 0.0; if (h < 0) h = 0; if (h > 1) h = 1; health = h; }
    protected static double get(Map<String, Double> in, String k, double def) {
        if (in == null || !in.containsKey(k) || in.get(k) == null) return def;
        double v = in.get(k); return (Double.isNaN(v) || Double.isInfinite(v)) ? def : v;
    }
    protected Map<String, Double> out(String key, double value) {
        HashMap<String, Double> m = new HashMap<String, Double>();
        m.put(key, value);
        m.put("phase", (double) phase);
        return m;
    }
}
