package com.hiveminemobile.ai.loot;

/** Crafting / gear materials the user may farm toward. */
public enum CraftMaterial {
    GLUE,
    GUMDROPS,
    GUMMY_BEE_EGG_RELATED,
    TICKETS,
    TREATS,
    SUNFLOWER_SEED,
    STRAWBERRY,
    PINEAPPLE,
    BLUEBERRY,
    COCONUT,
    ENZYMES,
    OIL,
    EXTRACTS,
    GLITTER,
    SOFT_WAX,
    HARD_WAX,
    SWORDS,
    TOKENS_GENERIC,
    HONEY,
    UNKNOWN
}
