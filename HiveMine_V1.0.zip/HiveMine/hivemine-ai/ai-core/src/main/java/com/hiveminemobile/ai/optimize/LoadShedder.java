package com.hiveminemobile.ai.optimize;
/** Phase 087 — Drops low-priority work when pressure is high. */
public final class LoadShedder {
    public enum Priority { CRITICAL, HIGH, NORMAL, LOW }
    private final double dropNormalAbove;
    private final double dropHighAbove;
    public LoadShedder(double dropNormalAbove, double dropHighAbove) {
        this.dropNormalAbove = dropNormalAbove;
        this.dropHighAbove = dropHighAbove;
    }
    /** pressure 0..1 */
    public boolean allow(Priority p, double pressure) {
        if (p == null) return false;
        if (p == Priority.CRITICAL) return true;
        if (pressure >= dropHighAbove && p != Priority.CRITICAL) {
            return p == Priority.HIGH && pressure < 1.0;
        }
        if (pressure >= dropNormalAbove && (p == Priority.NORMAL || p == Priority.LOW)) return false;
        if (p == Priority.LOW && pressure >= dropNormalAbove * 0.5) return false;
        return true;
    }
}
