package com.hiveminemobile.ai.memory;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.OptionalDouble;

/** Bounded history of manager decisions and their results. The oldest records are evicted first. */
public final class ManagerMemory {
    private final int capacity;
    private final ArrayDeque<DecisionRecord> records = new ArrayDeque<>();
    private long nextSequence = 1L;

    public ManagerMemory(int capacity) {
        if (capacity < 1) throw new IllegalArgumentException("capacity must be at least 1");
        this.capacity = capacity;
    }

    public synchronized DecisionRecord record(String taskId, String capability, String specialistId,
                                              String decision, DecisionRecord.Outcome outcome,
                                              String detail, long nowMillis) {
        if (decision == null || decision.trim().isEmpty()) throw new IllegalArgumentException("decision must not be blank");
        if (outcome == null) throw new IllegalArgumentException("outcome must not be null");
        String text = detail == null ? "" : detail.trim();
        if (text.length() > DecisionRecord.MAX_DETAIL_LENGTH) {
            text = text.substring(0, DecisionRecord.MAX_DETAIL_LENGTH);
        }
        DecisionRecord record = new DecisionRecord(nextSequence++, nowMillis, taskId, capability,
            specialistId, decision.trim(), outcome, text);
        while (records.size() >= capacity) records.removeFirst();
        records.addLast(record);
        return record;
    }

    /** Newest first. */
    public synchronized List<DecisionRecord> recent(int limit) {
        if (limit < 1) throw new IllegalArgumentException("limit must be at least 1");
        List<DecisionRecord> out = new ArrayList<>();
        Iterator<DecisionRecord> newestFirst = records.descendingIterator();
        while (newestFirst.hasNext() && out.size() < limit) out.add(newestFirst.next());
        return Collections.unmodifiableList(out);
    }

    public synchronized List<DecisionRecord> forTask(String taskId) {
        List<DecisionRecord> out = new ArrayList<>();
        if (taskId != null) {
            for (DecisionRecord record : records) if (taskId.equals(record.getTaskId())) out.add(record);
        }
        return Collections.unmodifiableList(out);
    }

    public synchronized int count(String capability, DecisionRecord.Outcome outcome) {
        int count = 0;
        for (DecisionRecord record : records) {
            if (capability != null && capability.equals(record.getCapability()) && record.getOutcome() == outcome) {
                count++;
            }
        }
        return count;
    }

    /** Success share over SUCCESS and FAILURE records only; UNKNOWN results do not count. */
    public synchronized OptionalDouble successRate(String capability) {
        int successes = count(capability, DecisionRecord.Outcome.SUCCESS);
        int total = successes + count(capability, DecisionRecord.Outcome.FAILURE);
        return total == 0 ? OptionalDouble.empty() : OptionalDouble.of((double) successes / total);
    }

    public synchronized int size() { return records.size(); }
}
