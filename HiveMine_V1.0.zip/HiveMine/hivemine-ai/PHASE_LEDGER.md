# HiveMineAI Phase Ledger

The ledger now distinguishes code presence from test and device evidence. A phase is not complete merely because an implementing class exists.

**Statuses**
- `SOURCE_PRESENT`: source/docs exist; not an assertion of functional completion.
- `JVM_VERIFIED`: phase-specific JVM checks pass.
- `ANDROID_INTEGRATED`: app-side adapter is wired to the Android runtime and covered by the app wiring harness.
- `DEVICE_VERIFIED`: exercised on a physical Android device.
- `RELEASE_VERIFIED`: lint/build/signing/release validation completed.
- `IN_PROGRESS`, `NOT_STARTED`, `BLOCKED`: work state.

| Phase group | Domain | Evidence status | Evidence / limitation |
|---|---|---|---|
| 001–002 | Foundation inspection/structure | SOURCE_PRESENT | Inspection and architecture documents |
| 003–010 | Foundation architecture and memory primitives | SOURCE_PRESENT | Core modules exist; not every phase has independent acceptance coverage |
| 011–020 | Manager and base specialist systems | SOURCE_PRESENT | Manager lifecycle and module implementations exist; runtime orchestration remains partial |
| 021–040 | Specialist systems | SOURCE_PRESENT | Specialist catalog contains 20 modules; most are analysis-only and are not individually orchestrated by Android runtime |
| 041–050 | Integration contracts | JVM_VERIFIED | `MacroPort`, controller, adapter contracts and unit tests |
| 051–060 | Farming intelligence | SOURCE_PRESENT | Analysis classes exist; only selected macro telemetry is currently fed into the live manager state |
| 061–080 | Automation and manager intelligence | SOURCE_PRESENT | Core planning/scheduling abstractions exist; end-to-end task execution is not wired |
| 081–084, 086–088 | Optimization/integration support | SOURCE_PRESENT | Source exists; full Android execution path not demonstrated |
| 085 | Android integration readiness | ANDROID_INTEGRATED | `AndroidIntegrationManager` uses real service and preference readiness; JVM wiring check |
| 089 | Macro communication bridge | ANDROID_INTEGRATED | Authorized controller path, one-second Android poll, command transition tests; physical-device behavior not yet verified |
| 090 | Configuration sync | SOURCE_PRESENT | Sync manager exists; current app settings applier commits and verifies supported `Config` values separately |
| 091–100 | Integration/e2e support | SOURCE_PRESENT | JVM integration abstractions exist; not evidence of APK/device e2e |
| 101–120 | Data layer | JVM_VERIFIED | Concrete phase subsystems 101–120 plus phase acceptance checks; Android event history uses SQLite adapter |
| 121–160 | Specialist extensions | SOURCE_PRESENT | 12 V2 specialists are one generic ranker (orders numeric inputs by value) and are listed in pending(), not registered. No domain scoring and no safety blocking yet |
| 161–190 | UI contracts | JVM_VERIFIED | Concrete phase subsystems 161–190 plus phase acceptance checks; Android UI wiring remains device-unverified |
| 191–220 | Merge readiness | SOURCE_PRESENT | MacroPortAdapterSpec only checks its own boolean inputs; it does not inspect the real MacroPort. Real merge check still required |
| 221–250 | Release/delivery | JVM_VERIFIED | Concrete release phase subsystems 221–250 and acceptance checks pass; Android build/signing/device gates remain |

## Current verification snapshot

Last checked against the reviewed HiveMine project.

- Engine JVM suite: `bash tests/run.sh` (repo root) — **476 passed, 0 failed**.
- ai-core suite: `bash hivemine-ai/tests/run.sh` — **1154 passed, 0 failed**.
- AI/app wiring suites: `bash tests/run-ai.sh` — **exit 0, no failures** (wiring harness 33 checks).
- Gradle offline build: **BLOCKED** here, because Gradle 8.9 is not cached and `services.gradle.org` cannot be reached.
- Android lint, APK build, device validation and release signing: **NOT RUN**.

## Safety gate

`ActionSafetyGate` blocks farm, convert and recover commands when the macro is disconnected, its status has no timestamp, is more than 3 seconds old or from the future, or a recovery is in progress. Stop and shutdown are never gated. The runtime holds the action and says so (`HELD by safety gate: ...`). The runtime already had a 3-second freshness hold on the screen observation, which runs first; the gate adds the recovery-in-progress guard and a single shared rule. The manager's safety votes now come from this gate instead of a fixed value.

Limit: the gate covers the autonomous path. The user's own start and recover buttons go through `AutomationController` directly and are not gated by it.

## Learning

When a farm session ends, `ManagerRuntimeService.learnFromSession` compares its pollen rate with the previous session. Sessions under a minute, or with no pollen observed, are ignored. The first counted session sets the baseline. A better session raises the farm bias, and a worse one lowers it. The biases are saved to the `learned_bias` table (database version 4) when a session ends and at each manager-state save, and restored at startup.

Limit: the learning signal is pollen rate only. It is not yet tied to bag fill or quest outcomes.

## Bug review (this pass)

Fixed:
- App would not compile: a missing import for `ObservationFreshness`, a `cfg.autoFarm` reference to a field that doesn't exist (the dashboard now reads `aiPollenMode`, the closest setting), and a call to `ui.body` with four arguments, which takes one.
- Screenshot paths used `takeScreenshot` (Android 11+) on phones with minimum Android 8. The check and calibration buttons now show a message on older versions.
- Adaptive decisions skipped the escalation override. Escalation was never fed a failure. Live outcomes now feed it. The startup replay of saved history does not.
- Overnight: the 20-minute delayed start reused the screen-off action, so it never started the macro. It has its own action now. Scheduled starts respect Safe Mode, so an emergency stop is not undone.

Not in this tree: the emergency-stop notification, crash log and update check were built in a different copy. This build does not include them.

## Open items

- **60 phases are unverified:** 021–040 and 121–160 need the 12 generic specialists (Field through Safety). They are listed in `SpecialistCatalogFactory.pending()`, not registered, until real domain logic exists. `PhaseExecutor` reports them as "specialists not implemented".
- **Phase status markers:** `PhaseCatalog` marks the 60 specialist phases `PENDING`, so `implementedCount()` is 190. A test checks that every status matches the verifier.
- **Merge:** the real HiveMine MacroPort is not checked. `MacroPortAdapterSpec` only validates its own inputs.
- **Device:** nothing has run on a phone. See `DEVICE_TEST_MATRIX.md`.
- **App code is not compiled against the Android SDK.** The harness parses and checks the edited app files with stubs. It found and fixed two broken string literals in `MainActivity` that would have stopped the build. `MainActivity` is not covered by the harness.

## Important interpretation

The range rows above group related phases. They do not replace 250 individual acceptance checks. Only phases with explicit evidence receive `JVM_VERIFIED` or `ANDROID_INTEGRATED`. No phase is `DEVICE_VERIFIED` or `RELEASE_VERIFIED` yet.

Superseded pass and report documents are in `docs/archive/`.
